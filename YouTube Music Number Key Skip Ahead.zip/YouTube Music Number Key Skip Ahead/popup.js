document.getElementById("logButton").addEventListener("click", () => {
    console.log("Popup button clicked.");
  });
  